# 获取用户输入的 RPC 地址或使用默认地址
RPC_URL=https://nixie-whcaub-fast-mainnet.helius-rpc.com

# 获取用户输入的线程数或使用默认值
THREADS=100

# 获取用户输入的优先费用或使用默认值
PRIORITY_FEE=100000

while true; do ore --rpc $RPC_URL --keypair solana-keygen-output.txt --priority-fee $PRIORITY_FEE mine --threads $THREADS; echo '进程异常退出，等待重启' >&2; sleep 1; done